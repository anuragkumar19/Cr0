// Import modules
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

// PORT
const PORT = process.env.PORT || 5000;

// Initilize app
const app = express();


try {
    mongoose.connect('mongodb+srv://admin:admin@m-lab.cbmpx.azure.mongodb.net/restApi?retryWrites=true&w=majority', {
        useNewUrlParser: true, useUnifiedTopology: true
    });
} catch (err) {
    console.log(err);
}

// Express middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({
    extended: true
}));

// route
app.use('/api', require('./routes/api'));


// Server
app.listen(PORT, () => console.log(`Server running in ${process.env.NODE_ENV} on  ${PORT}`));