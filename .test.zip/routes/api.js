const router = express.Router();
const post = require("../modal/Post");


router.get('/', async (req, res) => {
    let allPosts = await post.find();

    res.json(allPosts);
});

router.post('/', async (req, res) => {
    let newPost = new post(req.body);
    let n = await newPost.save();

    res.json(n);
});



module.export = router;